                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2371117
MTvplot (vertical plotter) by Michi_Teck is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

After i discovered the wonderful vertical plotter made by rincey12 and his awesome diy-manual (@ makerblog.at) i decided to make a quite similar design from scratch (and try to improve some known problems by throwing in some bearings). 

For the gondola-arms i printed them @100% infill and drilled the small holes (for the cord and the set screws to secure it) afterwards to gain some weight and stability. My whiteboard-markers are ~17mm in diameter, so i used a 20mm aluminium tube as gondola-core and some set screws to be able to use smaller pens (whithout changing the mid-point). Between the bearings i used a printed 0.5mm spacer (some more sizes included).

As i wanted to try it on my already mounted whiteboard, i made some 'front-side' holders for the stepper motors (to quickly screw them to your wall-of-interest). The gears are sized for a roller blind cord with a sphere diameter of 4,5mm and a distance (mid-sphere to mid-sphere) of 12mm.

To finally operate it, i used the fantastic polargraph-code made by Sandy Noble.

Part-list:
5m roller blind cord 4,5/12
2x deep groove ball bearing 6004 2RS 20x42x12 mm
2x stepper motor - NEMA-17 200 steps/rev, 12V 350mA
1x Geekcreit UNO R3 ATmega328P Development Board For Arduino
1x Motor Drive Shield L293D For Arduino
8x set screws M4 (10mm)
1x aluminium tube (20mm outer diameter, 1mm thick)
some M2/M3/M4 screws to secure the motor holders, servo and gears

(all these parts + shipping to germany cost me around 80€ in the end)

Big THX to all previous makers and coders providing awesome ideas/manuals & software, this was/is a very cool project. Happy for questions/remarks if you have some.

# Print Settings

Printer: Anet A8
Rafts: No
Supports: Yes
Resolution: .2
Infill: 100 (motor holders 50)

Notes: 
NGEN with ext/bed 225/80°C on glass

# How I Designed This

Fusion 360