package controlP5;

class Tooltip {
	// TODO a tooltip for controllers. on enter, on leave.
}
