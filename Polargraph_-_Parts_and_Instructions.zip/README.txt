                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:575487
Polargraph - Parts and Instructions by jolars is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

I am going to say that I am just basing my work on that of others - these are just what I did with the existing information and models.  

I followed this tutorial for my entire assembly, adapting where it made sense - http://www.instructables.com/id/Polargraph-Drawing-Machine/  

Also this site for more information and up to date software http://www.polargraph.co.uk/  

I am using two nema 17 motors from Adafruit.  The motors are run with an arduino Uno and adafruit v1 motorshield (I had this just laying around, it turns out that it works perfect with the 'firmware' for the bot).  I have a 12v 1.5a power supply running the motor shield and I have isolated (through removal of the jumper on the board) it from the Uno which is getting power and information from my PC. Two 6' 3.5mm ball chains are being used as both gears and pulleys for the system - these work great for this project.   

I flashed the 'firmware' from this github https://github.com/euphy/polargraphcontroller/releases/latest  

The firmware is a set of Uno sketches which you will need to adjust for whatever motor shield you are using - it appears V2 is more problematic than V1, but that is just from a few posts I have read.  V1 is working fine for me.  

The software is located here https://github.com/euphy/polargraphcontroller/releases/tag/1.10.6a  

Read the wiki for more info on the software release - https://github.com/euphy/polargraph  

It was pretty intuitive after a little bit of use.  Restart quite a bit.  

Make sure you follow the instructions on calibrating your machine on the indestructables, it corrected many issues my machine had out of the gate.